import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;

public class BankRecords extends Client{
	
	//All variables need to display data
	String id;
	int age;
	String sex;
	String region;
	double income;
	String married; 
	int children;
	String car;
	String save_act;
	String current_act;
	String mortgage;
	String pep;
	
	//array of BankRecords objects
	static BankRecords arrayOfBankRecordObjects[] = new BankRecords[600]; 
	
	//arraylist to hold spreadsheet rows & columns
	static ArrayList<List<String>> arrayWithData = new ArrayList<>();  
	
	//To get the input for the number of records to display
	Scanner scannerObjectForInputs = new Scanner(System.in);

	
	//All getter and setters for id,age,sex,region,income,region,car,children,savings account ,current account mortgage,pep
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public double getIncome() {
		return income;
	}
	public void setIncome(double income) {
		this.income = income;
	}
	public String getMarried() {
		return married;
	}
	public void setMarried(String married) {
		this.married = married;
	}
	public int getChildren() {
		return children;
	}
	public void setChildren(int children) {
		this.children = children;
	}
	public String getCar() {
		return car;
	}
	public void setCar(String car) {
		this.car = car;
	}
	public String getSave_act() {
		return save_act;
	}
	public void setSave_act(String save_act) {
		this.save_act = save_act;
	}
	public String getCurrent_act() {
		return current_act;
	}
	public void setCurrent_act(String current_act) {
		this.current_act = current_act;
	}
	public String getMortgage() {
		return mortgage;
	}
	public void setMortgage(String mortgage) {
		this.mortgage = mortgage;
	}
	public String getPep() {
		return pep;
	}
	public void setPep(String pep) {
		this.pep = pep;
	}
	
	
	@Override
	public void readDataFromFile() {
		// TODO Auto-generated method stub
		try {
			BufferedReader bufferedReader = new BufferedReader(new FileReader(new File("bank-Detail.csv")));
			//String to Store Data read each line
			String oneLineData;
			//Read the CSV file bank-Detail
			while((oneLineData = bufferedReader.readLine())!=null) {
				arrayWithData.add(Arrays.asList(oneLineData.split(",")));
				//System.out.println(oneLineData);
			}
			//call function for processing record data
			processDataFromFile();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(""+e);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	@Override
	public void processDataFromFile() {
		// TODO Auto-generated method stub
		int index = 0;
		for (List<String> rowData: arrayWithData) {
		        //initialize array of objects
		    	arrayOfBankRecordObjects[index] = new BankRecords();
		    	//call setters below and populate them, item by item
		    	arrayOfBankRecordObjects[index].setId(rowData.get(0)); //get 1st column
		    	arrayOfBankRecordObjects[index].setAge(Integer.parseInt(rowData.get(1))); //get 2nd column
		    	arrayOfBankRecordObjects[index].setSex(rowData.get(2));//get 3rd column
		    	arrayOfBankRecordObjects[index].setRegion(rowData.get(3)); //get 4th column
		    	arrayOfBankRecordObjects[index].setIncome(Double.parseDouble(rowData.get(4)));//get 5th column
		    	arrayOfBankRecordObjects[index].setMarried(rowData.get(5));//get 6th column
		    	arrayOfBankRecordObjects[index].setChildren(Integer.parseInt(rowData.get(6)));//get 7th column
		    	arrayOfBankRecordObjects[index].setCar(rowData.get(7));//get 8th column
		    	arrayOfBankRecordObjects[index].setSave_act(rowData.get(8)); //get 9th column
		    	arrayOfBankRecordObjects[index].setCurrent_act(rowData.get(9)); //get 10th column
		    	arrayOfBankRecordObjects[index].setMortgage(rowData.get(10));//get 11th column
		    	arrayOfBankRecordObjects[index].setPep(rowData.get(11));//get 12th column
                /*continue processing arraylist item values into each array object-> arrayOfBankRecordObjects[] by index*/
		    	index++;
        }	
		//Call the print fucntion to display the output 
		printDataFromFile();
	}
	@Override
	public void printDataFromFile() {
		// TODO Auto-generated method stub
		//To get the current timestamp
		String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
		
		//Print the output 
		System.out.println("Welcome to Bank of IIT - Chicago Customer Information Section........");
		System.out.println("CSV Record Opened at " + timeStamp);
		//Get the number of record to be display 
		System.out.println("Enter number of record to be displayed....");
		int tempInput = scannerObjectForInputs.nextInt();
		//Input check if it is less than 600 
		if(tempInput <= 600) {
		System.out.println("CWID\t\tAge\t\tGender\t\tLocality\t\tIncome\t\t\tMarried\t\tChildren\tOwnCar\t\tSavingAccount"
				+ "\t\tCurrentAccount\t\tMortgage\t\tPep");
		//Loop to iterate all the objects
			for (int tempIndex = 0; tempIndex < tempInput; tempIndex++) {		 
			  System.out.println(arrayOfBankRecordObjects[tempIndex].getId()+"\t\t" +
					  arrayOfBankRecordObjects[tempIndex].getAge()+"\t\t" +
					  arrayOfBankRecordObjects[tempIndex].getSex()+"\t\t" +
					  String.format("%-15s", arrayOfBankRecordObjects[tempIndex].getRegion())+"\t\t" + 
					  String.format("%8.2f", arrayOfBankRecordObjects[tempIndex].getIncome())+"\t\t" +
					  String.format("%-3s",arrayOfBankRecordObjects[tempIndex].getMarried())+"\t\t" +
					  String.format("%-2d",arrayOfBankRecordObjects[tempIndex].getChildren())+"\t\t" + 
					  /*String.format("%-6s",)*/arrayOfBankRecordObjects[tempIndex].getCar()+"\t\t" +
					  arrayOfBankRecordObjects[tempIndex].getSave_act()+"\t\t\t" +
					  arrayOfBankRecordObjects[tempIndex].getCurrent_act()+"\t\t\t" +
					  arrayOfBankRecordObjects[tempIndex].getMortgage()+"\t\t\t" +
					  arrayOfBankRecordObjects[tempIndex].getPep()+"\t\t");		  	
			}
		} else {
			//If user inputs more than 600
			System.out.println("Please enter records within limit of the file- 600 \n");
			printDataFromFile();
		}
		
		//To display the total records
		System.out.println("Total Records in CSV file " +arrayOfBankRecordObjects.length);
		//End Statement
		System.out.println("Thank You For Banking With Us... \n");
		//To display the current timestamp and the Programmer info
  	    System.out.println("Current Date and Time = " + timeStamp + "\nProgrammed by Ritesh Shenoy B\n");
		
	}

}
