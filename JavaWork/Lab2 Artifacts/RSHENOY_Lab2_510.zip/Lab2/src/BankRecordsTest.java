
public class BankRecordsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Creating a object bankRecord
		BankRecords bankRecords = new BankRecords();
		//Calling the read function of class BankRecords
		bankRecords.readDataFromFile();
	}

}
