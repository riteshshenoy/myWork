
/*AccountHolderTest class 
 * created by rshenoy
 * Ritesh Shenoy B
 * Lab 1 ITMD 510*/

public class AccountHolder {
	
	//Field for storing annual interest rate
	static double annualInterestRate;
	//Field for mainBalnce in user account
	double mainBalance = 0.0;
	
    //Parameterized Constructor with initial balance as a argument	
	public AccountHolder(double mainBalance) {
		this.mainBalance = mainBalance;
	}
	
	//Deposit money Function
	public void depositMoney(double depositMoney) {
		if(depositMoney <= 0.0) {
			System.out.println("Balance must be non-negative/Zero");
		} else {
		    mainBalance = mainBalance + depositMoney;		    
		}
		
	}
	
	//WithDraw money Function with all the check
    public void withDrawlMoney(double withDrawAmount) {  
    	double tempBalance = mainBalance;
    	mainBalance = mainBalance - withDrawAmount;
    	//Check the balance is less than 100
    	if (mainBalance < 100 ) {
    		System.out.println("You cannot withdraw this amount balance might go below $100");
    		mainBalance = tempBalance;
    	} else if(mainBalance > 150 && mainBalance <= 500) {  //Check if the balance amount comes between 150 to 500 and if yes penalize with $50
    			System.out.println("Your Amount will be penalised with $50");
    			mainBalance = mainBalance - 50; //$50 deduction for withdrawing when having a balance less than 500
    			System.out.println("Current Balance: " +mainBalance);
    		
    	} else if(mainBalance >=100 && mainBalance <=150 ) { //Check if the balance amount is less than 150, then penalize them with $50 in the withdrawal amount
    		System.out.println("Your Amount will be penalised with $50");   
    		if(withDrawAmount <=50) {
      		  System.out.println("You cannot withdraw this amount");
      		  mainBalance = tempBalance;      		 
    		} else {
    			withDrawAmount = withDrawAmount - 50;
        		System.out.println("Withdrawl amount: "+withDrawAmount);
    		}    		
    		System.out.println("Current Balance: " +mainBalance);
    	} else {
    		System.out.println("Your Availiable Balance: " +mainBalance);
    	}
	}
    
    //Function to calculate the monthly rate of interest
    public void monthlyInterest() {
    	mainBalance += mainBalance * (annualInterestRate / 12.0);  	
    }
    
    //Function to change the current rate of interest
    public static void modifymonthlyInterest(double newInterestRate) {
    	if (newInterestRate <= 0.0 && newInterestRate > 10) {
    		System.out.println("Interest cannot be less than or equal to 0 or greater than 10");
    	} else {
    		annualInterestRate = newInterestRate;
    		System.out.println("Your Interset Rate is changed to " +annualInterestRate + "%");    		
    	}	
    }
    
    //Function call to display menu option page
    public void menuOptions() {
    	System.out.println("Please Choose any one of following options..... ");	
    	System.out.println("1. Deposit Amount.............................. ");
		System.out.println("2. WithDrawal Amount........................... ");
		System.out.println("3. Modify the Rate of interest................. ");
		System.out.println("4. Generate Interest Report For 1 year......... ");
		System.out.println("5. Balance Check............................... ");
		System.out.println("6. Exit from Application....................... ");
    }
}
