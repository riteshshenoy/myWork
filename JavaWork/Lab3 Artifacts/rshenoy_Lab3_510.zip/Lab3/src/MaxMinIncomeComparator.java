import java.util.Comparator;

public class MaxMinIncomeComparator implements Comparator<BankRecords> {

	@Override
	public int compare(BankRecords arg0, BankRecords arg1) {
		// TODO Auto-generated method stub
		int result = new Double (arg0.getIncome()).compareTo(arg1.getIncome());
		return result;
	}
}
