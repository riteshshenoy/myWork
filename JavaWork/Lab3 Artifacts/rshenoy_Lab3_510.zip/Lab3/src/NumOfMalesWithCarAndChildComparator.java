import java.util.Comparator;

public class NumOfMalesWithCarAndChildComparator implements Comparator<BankRecords> {

	@Override
	public int compare(BankRecords arg0, BankRecords arg1) {
		// TODO Auto-generated method stub
		int result = arg0.getSex().compareTo(arg1.getSex());
		return result;
	}
}
