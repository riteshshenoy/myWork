package controllers;


import java.sql.ResultSet;


import BankRecords.BankRecords;
import models.DaoModel;
import views.LoanView;
import BankRecords.Records;

public class LoanProcessing extends BankRecords { 
	
	public static void main(String[] args)  {
		BankRecords br = new BankRecords();
		br.readDataFromFile();
		Records rec = new Records();
		rec.RegionAverageComp(); // analyze average income per loc
		rec.MaxMinIncomeComp();  //compare max and min incomes per loc  
		rec.FemalesWithMoratgeAndSavingsAccountComp();    //  analyze females w. mort/savings accounts per loc
		rec.MalesWithCarAndChildComp();  // analyze male count w. car and 1 child per loc 
		rec.MaxMinAge(); 
		DaoModel dao = new DaoModel();
		dao.createTable();
		dao.insertRecords(arrayOfBankRecordObjects); // perform inserts
		ResultSet rs = dao.retrieveRecords();
		new LoanView().runView(rs); 
		Serialize serialize = new Serialize();
		System.out.print("Serlizing the Data of id objects\n");
		serialize.Serlize();
		System.out.print("Sleeping the application for 5 seconds\n");
		try {
			Thread.sleep(5);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.print("Deserlizing the Data of id objects\n");
		serialize.deSerilize();
		//Calculate the time
		serialize.calculateTime();
	}
}
