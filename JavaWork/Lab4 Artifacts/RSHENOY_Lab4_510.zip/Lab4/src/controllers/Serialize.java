package controllers;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import BankRecords.BankRecords;

public class Serialize extends BankRecords {
	String filename = "bankrecords.ser";
	Map<Integer,String> dataToSerlize = new HashMap<Integer, String>();
	
	//To get the current timestamp
	String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
	private long endTime;
	private long startTime;
	public void Serlize() {
		
		for (int i = 0; i <arrayOfBankRecordObjects.length; i++) {
			dataToSerlize.put(i, arrayOfBankRecordObjects[i].getId());
		}

		// Serialization  
		try{    
			//Saving of object in a file 
			FileOutputStream file = new FileOutputStream(filename); 
			ObjectOutputStream out = new ObjectOutputStream(file); 
			// Method for serialization of object 
			out.writeObject(dataToSerlize); 
			out.close(); 
			file.close(); 
			startTime = System.nanoTime();
			System.out.println("Object has been serialized"); 
		} 
		catch(IOException ex) { 
			System.out.println("IOException is caught"); 
		} 
	}
	
	public void deSerilize() {
		int len =1;
		//Deserialization 
        try
        {    
            // Reading the object from a file 
            FileInputStream file = new FileInputStream(filename); 
            ObjectInputStream in = new ObjectInputStream(file); 
              
            // Method for deserialization of object 
            @SuppressWarnings("rawtypes")
			Map dataDeserilize = (Map)in.readObject(); 
              
            in.close(); 
            file.close(); 
            endTime   = System.nanoTime();  
            System.out.println("Object has been deserialized "); 
            for (int i = 0; i <arrayOfBankRecordObjects.length; i++) {
            	System.out.println("Data of key " + len  + "=> ID:" + dataDeserilize.get(i));
            	len++;
            }
            
            //To display the total records
			System.out.println("Total Records in CSV file " +arrayOfBankRecordObjects.length);
			//End Statement
			System.out.println("Thank You For Banking With Us... \n");
			//To display the current timestamp and the Programmer info
	  	    System.out.println("Current Date and Time = " + timeStamp + "\nProgrammed by Ritesh Shenoy B\n");
        } 
        catch(IOException ex) { 
            System.out.println("IOException is caught"); 
        } 
          
        catch(ClassNotFoundException ex) { 
            System.out.println("ClassNotFoundException is caught"); 
        } 
	}
	
	public void calculateTime() {
		long totalTime = endTime - startTime;
		System.out.print("Calculated time between Serilize and DeSerilize = " +totalTime/1000000 + "ms");
	}
}

