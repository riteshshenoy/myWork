package BankRecords;
//Abstract Client Class
public abstract class Client {
	
	//Function To read the file
	public abstract void readDataFromFile();
	
	//Function To process the file
	public abstract void processDataFromFile();
	
	//Function To print the file
	//public abstract void printDataFromFile(); 
	
}
