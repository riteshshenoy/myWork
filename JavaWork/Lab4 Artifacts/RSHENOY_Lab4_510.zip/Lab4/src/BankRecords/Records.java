package BankRecords;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;

public class Records extends BankRecords {
	
	//create formatted object to write output directly to the
	//console and to a file
	static FileWriter fw = null;

	
		public Records(){
			try {
				fw = new FileWriter("bankrecords.txt");
			} catch (IOException e) {
				e.printStackTrace();
			} 
		}

		public static void main(String[] args)  {
			Records br = new Records();
			
			//To read from the file bank-detail.csv
			br.readDataFromFile();
			
			/*//To display initial message 
			System.out.printf("Programmed by Ritesh Shenoy B\n");
			System.out.printf("Welcome to Bank of IIT Chicago Customer Record Genereation Section...\n\n");*/
			
			//call functions to perform analytics 
			RegionAverageComp(); // analyze average income per loc
			MaxMinIncomeComp();  //compare max and min incomes per loc  
			FemalesWithMoratgeAndSavingsAccountComp();    //  analyze females w. mort/savings accounts per loc
			MalesWithCarAndChildComp();  // analyze male count w. car and 1 child per loc 
			MaxMinAge(); // anlayze max and minimum age
		
			//To get the current timestamp
			String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
			
			//To display the total records
			System.out.println("Total Records in CSV file " +arrayOfBankRecordObjects.length);
			//End Statement
			System.out.println("Thank You For Banking With Us... \n");
			//To display the current timestamp and the Programmer info
	  	    System.out.println("Current Date and Time = " + timeStamp + "\nProgrammed by Ritesh Shenoy B\n");
			
			// *** close out file object ***//
			try {
				fw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		//To find the average income accoring to various regions
		public static void RegionAverageComp() {

			Arrays.sort(arrayOfBankRecordObjects,new RegionComparator());
			//set up needed vars for region counts & incomes per loc
			double townCount = 0;
			double innerCityCount = 0;
			double suburbanCount = 0;
			double ruralCount = 0;
			double townIncomeSum = 0;
			double innerCityIncomeSum = 0;
			double suburbanIncomeSum = 0;
			double ruralIncomeSum = 0;

			for (int i=0;i<arrayOfBankRecordObjects.length;i++) {
				if (arrayOfBankRecordObjects[i].getRegion().equals("RURAL")) { 
					ruralIncomeSum += arrayOfBankRecordObjects[i].getIncome();
					++ruralCount;
				}else if (arrayOfBankRecordObjects[i].getRegion().equals("INNER_CITY")){
					innerCityIncomeSum += arrayOfBankRecordObjects[i].getIncome();
					++innerCityCount;
				}else if (arrayOfBankRecordObjects[i].getRegion().equals("TOWN")){
					townIncomeSum += arrayOfBankRecordObjects[i].getIncome();
					++townCount;
				}else if (arrayOfBankRecordObjects[i].getRegion().equals("SUBURBAN")){
					suburbanIncomeSum += arrayOfBankRecordObjects[i].getIncome();
					++suburbanCount;
				}
			}
			//setup resulting averages to print to console and to file
			double ruralAvg = ruralIncomeSum/(ruralCount);
			double innerCityAvg = innerCityIncomeSum/(innerCityCount);
			double townAvg = townIncomeSum/(townCount);
			double suburbanAvg = suburbanIncomeSum/(suburbanCount);


			//Print the output of average value as per location
			System.out.printf("Data analytic results:\n");
			System.out.printf("AVERAGE INCOME PER LOCATION \n");
			System.out.printf("Innercity region total count:" +String.format("%8s", innerCityCount) + "\n");
			System.out.printf("Innercity region total Income:\t" + String.format("%.2f", innerCityIncomeSum) + "\n" );
			System.out.printf("Innercity region average income:" + String.format("%.2f", innerCityAvg) + "\n");
			System.out.printf("\n");

			System.out.printf("Rural region total:" +String.format("%17s", ruralCount) + "\n");
			System.out.printf("Rural region total Income:\t" + String.format("%.2f", ruralIncomeSum) + "\n");
			System.out.printf("Rural region average income:\t" + String.format("%.2f", ruralAvg) + "\n");
			System.out.printf("\n");


			System.out.printf("Suburban region total:" +String.format("%14s", suburbanCount) + "\n");
			System.out.printf("Suburban region total Income:\t" + String.format("%.2f", suburbanIncomeSum) + "\n");
			System.out.printf("Suburban region average income:\t" + String.format("%.2f", suburbanAvg) + "\n");
			System.out.printf("\n");

			System.out.printf("Town region total:" +String.format("%19s", townCount) + "\n");
			System.out.printf("Town region total Income:\t" + String.format("%.2f", townIncomeSum) + "\n");
			System.out.printf("Town region average income:\t" + String.format("%.2f", townAvg) + "\n");
			System.out.printf(".........................................\n");

			//To write to bankrecords.txt file
			try {
				fw.write("Data analytic results:\n");
				fw.write("AVERAGE INCOME PER LOCATION \n");
				fw.write("Innercity region total count:" +String.format("%8s", innerCityCount) + "\n");
				fw.write("Innercity region total Income:\t" + String.format("%.2f", innerCityIncomeSum) + "\n" );
				fw.write("Innercity region average income:" + String.format("%.2f", innerCityAvg) + "\n");
				fw.write("\n");

				fw.write("Rural region total:" +String.format("%17s", ruralCount) + "\n");
				fw.write("Rural region total Income:\t" + String.format("%.2f", ruralIncomeSum) + "\n");
				fw.write("Rural region average income:\t" + String.format("%.2f", ruralAvg) + "\n");
				fw.write("\n");


				fw.write("Suburban region total:" +String.format("%14s", suburbanCount) + "\n");
				fw.write("Suburban region total Income:\t" + String.format("%.2f", suburbanIncomeSum) + "\n");
				fw.write("Suburban region average income:\t" + String.format("%.2f", suburbanAvg) + "\n");
				fw.write("\n");

				fw.write("Town region total:" +String.format("%19s", townCount) + "\n");
				fw.write("Town region total Income:\t" + String.format("%.2f", townIncomeSum) + "\n");
				fw.write("Town region average income:\t" + String.format("%.2f", townAvg) + "\n");
				fw.write(".........................................\n");

			} catch (IOException e) {
				e.printStackTrace();
			}  
		}
		
		public static void MaxMinIncomeComp() {
			// TODO Auto-generated method stub
			Arrays.sort(arrayOfBankRecordObjects,new MaxMinIncomeComparator());
			
			double maxIncomeRural = 0;
			double maxIncomeInnerCity = 0;
			double maxIncomeSuburban = 0;
			double maxIncomeTown = 0;
			
			double minIncomeRural = 0;
			double minIncomeInnerCity = 0;
			double minIncomeSuburban = 0;
			double minIncomeTown = 0;
			
			for (int i=0;i<arrayOfBankRecordObjects.length;i++) {
				
				if(arrayOfBankRecordObjects[i].getRegion().equals("RURAL")) {
					maxIncomeRural = arrayOfBankRecordObjects[i].getIncome();
					minIncomeRural = arrayOfBankRecordObjects[i].getIncome();
				} else if(arrayOfBankRecordObjects[i].getRegion().equals("INNER_CITY")) {
					maxIncomeInnerCity = arrayOfBankRecordObjects[i].getIncome();
					minIncomeInnerCity = arrayOfBankRecordObjects[i].getIncome();
				} else if(arrayOfBankRecordObjects[i].getRegion().equals("TOWN")) {
					maxIncomeTown = arrayOfBankRecordObjects[i].getIncome();
					minIncomeTown = arrayOfBankRecordObjects[i].getIncome();
				} else if(arrayOfBankRecordObjects[i].getRegion().equals("SUBURBAN")) {
					maxIncomeSuburban = arrayOfBankRecordObjects[i].getIncome();
					minIncomeSuburban = arrayOfBankRecordObjects[i].getIncome();
				}
			}
			
			
			for (int i=0;i<arrayOfBankRecordObjects.length;i++) {
				
				if(arrayOfBankRecordObjects[i].getRegion().equals("RURAL")) {
					if (arrayOfBankRecordObjects[i].getIncome() > maxIncomeRural ) {
						maxIncomeRural = arrayOfBankRecordObjects[i].getIncome();
					} 
					if (arrayOfBankRecordObjects[i].getIncome()  < minIncomeRural) {
						minIncomeRural = arrayOfBankRecordObjects[i].getIncome();
					}
				} else if(arrayOfBankRecordObjects[i].getRegion().equals("INNER_CITY")) {
					if (arrayOfBankRecordObjects[i].getIncome() > maxIncomeInnerCity) {
						maxIncomeInnerCity = arrayOfBankRecordObjects[i].getIncome();
					} 
					if (arrayOfBankRecordObjects[i].getIncome() < minIncomeInnerCity) {
						minIncomeInnerCity = arrayOfBankRecordObjects[i].getIncome();
					}
				} else if(arrayOfBankRecordObjects[i].getRegion().equals("TOWN")) {
					if (arrayOfBankRecordObjects[i].getIncome() > maxIncomeTown ) {
						maxIncomeTown = arrayOfBankRecordObjects[i].getIncome();
					} 
					if (arrayOfBankRecordObjects[i].getIncome() < minIncomeTown) {
						minIncomeTown = arrayOfBankRecordObjects[i].getIncome();
					}
				} else if(arrayOfBankRecordObjects[i].getRegion().equals("SUBURBAN")) {
					if (arrayOfBankRecordObjects[i].getIncome() > maxIncomeSuburban) {
						maxIncomeSuburban = arrayOfBankRecordObjects[i].getIncome();
					} 
					if (arrayOfBankRecordObjects[i].getIncome() < minIncomeSuburban ) {
						minIncomeSuburban = arrayOfBankRecordObjects[i].getIncome();
					}
				}			
			}
			
			//Print the output of maximum and minimum value as per location
			System.out.printf("MAXIMUM INCOME AS PER LOCATION \n");
			System.out.printf("Innercity region maximum income:" +String.format("%12s", maxIncomeInnerCity) + "\n");
			System.out.printf("Rural region maximum income:" +String.format("%15s", maxIncomeRural) + "\n");
			System.out.printf("Suburban region maximum income:" +String.format("%12s", maxIncomeSuburban)  + "\n");
			System.out.printf("Town region maximum income:" +String.format("%16s", maxIncomeTown)  + "\n"  + "\n");
			
			System.out.printf("MINIMUM INCOME AS PER LOCATION \n");
			System.out.printf("Innercity region minimum income: " +String.format("%10s", minIncomeInnerCity)  + "\n");
			System.out.printf("Rural region minimum income: " +String.format("%14s", minIncomeRural)  + "\n");
			System.out.printf("Suburban region minimum income: " +String.format("%11s", minIncomeSuburban)  + "\n");
			System.out.printf("Town region minimum income:" +String.format("%16s", minIncomeTown)  + "\n");
			System.out.printf("...............................................\n");
			
			//To write to bankrecords.txt file
			try {
				fw.write("MAXIMUM INCOME AS PER LOCATION \n");
				fw.write("Innercity region maximum income:" +String.format("%12s", maxIncomeInnerCity) + "\n");
				fw.write("Rural region maximum income:" +String.format("%15s", maxIncomeRural) + "\n");
				fw.write("Suburban region maximum income:" +String.format("%12s", maxIncomeSuburban)  + "\n");
				fw.write("Town region maximum income:" +String.format("%16s", maxIncomeTown)  + "\n"  + "\n");
				
				fw.write("MINIMUM INCOME AS PER LOCATION \n");
				fw.write("Innercity region minimum income: " +String.format("%10s", minIncomeInnerCity)  + "\n");
				fw.write("Rural region minimum income: " +String.format("%14s", minIncomeRural)  + "\n");
				fw.write("Suburban region minimum income: " +String.format("%11s", minIncomeSuburban)  + "\n");
				fw.write("Town region minimum income:" +String.format("%16s", minIncomeTown)  + "\n");
				fw.write("...............................................\n");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		public static void FemalesWithMoratgeAndSavingsAccountComp() {
			// TODO Auto-generated method stub
			
			int numberOfFemalesInRural = 0;
			int numberOfFemalesInInnerCity = 0;
			int numberOfFemalesInSuburban = 0;
			int numberOfFemalesInTown = 0;
			
			Arrays.sort(arrayOfBankRecordObjects,new NumOfFemalesWithMortAndSaviAccountComparator());
			
			for (int i=0;i<arrayOfBankRecordObjects.length;i++) {
				if(arrayOfBankRecordObjects[i].getRegion().equals("RURAL")) {
					if(arrayOfBankRecordObjects[i].getSex().equals("FEMALE") && 
							arrayOfBankRecordObjects[i].getMortgage().equals("YES") && 
							arrayOfBankRecordObjects[i].getSave_act().equals("YES")) {
						numberOfFemalesInRural++;
					}
					
				} else if(arrayOfBankRecordObjects[i].getRegion().equals("INNER_CITY")) {
					if(arrayOfBankRecordObjects[i].getSex().equals("FEMALE") && 
							arrayOfBankRecordObjects[i].getMortgage().equals("YES") && 
							arrayOfBankRecordObjects[i].getSave_act().equals("YES")) {
						numberOfFemalesInInnerCity++;
					}
					
				} else if(arrayOfBankRecordObjects[i].getRegion().equals("TOWN")) {
					if(arrayOfBankRecordObjects[i].getSex().equals("FEMALE") && 
							arrayOfBankRecordObjects[i].getMortgage().equals("YES") && 
							arrayOfBankRecordObjects[i].getSave_act().equals("YES")) {
						numberOfFemalesInTown++;
					}
					
				} else if(arrayOfBankRecordObjects[i].getRegion().equals("SUBURBAN")) {
					if(arrayOfBankRecordObjects[i].getSex().equals("FEMALE") && 
							arrayOfBankRecordObjects[i].getMortgage().equals("YES") && 
							arrayOfBankRecordObjects[i].getSave_act().equals("YES")) {
						numberOfFemalesInSuburban++;
					}
				}
			}
			
			//Print the output of number of females with both mortgage and savings account value as per location
			System.out.printf("NUMBER OF FEMALES WITH BOTH MORTGAGE AND SAVINGS ACCOUNT PER REGION \n");
			System.out.printf("Innercity:" +String.format("%3s", numberOfFemalesInInnerCity)  + "\n");
			System.out.printf("Rural:" +String.format("%6s", numberOfFemalesInRural)  + "\n");
			System.out.printf("Suburban:" +String.format("%3s", numberOfFemalesInSuburban)  + "\n");
			System.out.printf("Town:" +String.format("%8s", numberOfFemalesInTown)  + "\n"  + "\n");
			System.out.printf("...............................................\n");
			
			try {
				fw.write("NUMBER OF FEMALES WITH BOTH MORTGAGE AND SAVINGS ACCOUNT PER REGION \n");
				fw.write("Innercity:" +String.format("%3s", numberOfFemalesInInnerCity)  + "\n");
				fw.write("Rural:" +String.format("%6s", numberOfFemalesInRural)  + "\n");
				fw.write("Suburban:" +String.format("%3s", numberOfFemalesInSuburban)  + "\n");
				fw.write("Town:" +String.format("%8s", numberOfFemalesInTown)  + "\n"  + "\n");
				fw.write("...............................................\n");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		public static void MalesWithCarAndChildComp() {
			// TODO Auto-generated method stub
			
			int numberOfMalesInRural = 0;
			int numberOfMalesInInnerCity = 0;
			int numberOfMalesInSuburban = 0;
			int numberOfMalesInTown = 0;
			
			Arrays.sort(arrayOfBankRecordObjects,new NumOfMalesWithCarAndChildComparator());
			for (int i=0;i<arrayOfBankRecordObjects.length;i++) {
				if(arrayOfBankRecordObjects[i].getRegion().equals("RURAL")) {
					if(arrayOfBankRecordObjects[i].getSex().equals("MALE") && 
							arrayOfBankRecordObjects[i].getCar().equals("YES") && 
							arrayOfBankRecordObjects[i].getChildren() == 1) {
						numberOfMalesInRural++;
					}
					
				} else if(arrayOfBankRecordObjects[i].getRegion().equals("INNER_CITY")) {
					if(arrayOfBankRecordObjects[i].getSex().equals("MALE") && 
							arrayOfBankRecordObjects[i].getCar().equals("YES") && 
							arrayOfBankRecordObjects[i].getChildren() == 1) {
						numberOfMalesInInnerCity++;
					}
					
				} else if(arrayOfBankRecordObjects[i].getRegion().equals("TOWN")) {
					if(arrayOfBankRecordObjects[i].getSex().equals("MALE") && 
							arrayOfBankRecordObjects[i].getCar().equals("YES") && 
							arrayOfBankRecordObjects[i].getChildren() == 1) {
						numberOfMalesInTown++;
					}
					
				} else if(arrayOfBankRecordObjects[i].getRegion().equals("SUBURBAN")) {
					if(arrayOfBankRecordObjects[i].getSex().equals("MALE") && 
							arrayOfBankRecordObjects[i].getCar().equals("YES") && 
							arrayOfBankRecordObjects[i].getChildren() == 1) {
						numberOfMalesInSuburban++;
					}
				}
			}
			//Print the output of number of males with both car and one children value as per location
			System.out.printf("NUMBER OF MALES WITH BOTH A CAR AND ONE CHIDLREN PER REGION \n");
			System.out.printf("Innercity:" +String.format("%3s", numberOfMalesInInnerCity)  + "\n");
			System.out.printf("Rural:" +String.format("%6s", numberOfMalesInRural)   + "\n");
			System.out.printf("Suburban:" +String.format("%3s", numberOfMalesInSuburban)  + "\n");
			System.out.printf("Town:" +String.format("%7s", numberOfMalesInTown)  + "\n"  + "\n");
			System.out.printf("...............................................\n");
			
			try {
				fw.write("NUMBER OF MALES WITH BOTH A CAR AND ONE CHIDLREN PER REGION \n");
				fw.write("Innercity:" +String.format("%3s", numberOfMalesInInnerCity)  + "\n");
				fw.write("Rural:" +String.format("%6s", numberOfMalesInRural)   + "\n");
				fw.write("Suburban:" +String.format("%3s", numberOfMalesInSuburban)  + "\n");
				fw.write("Town:" +String.format("%7s", numberOfMalesInTown)  + "\n"  + "\n");
				fw.write("...............................................\n");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		public static void MaxMinAge() {
			// TODO Auto-generated method stub
			int maxAge = 0;
			int minAge = 100;
			
			for (int i=0;i<arrayOfBankRecordObjects.length;i++) {
				if(arrayOfBankRecordObjects[i].getAge() > maxAge) {
					maxAge = arrayOfBankRecordObjects[i].getAge();
				}
				if(arrayOfBankRecordObjects[i].getAge() < minAge) {
					minAge = arrayOfBankRecordObjects[i].getAge();
				}				
			}
			
			//Print the output of maximum and minimum age value as per location
			System.out.printf("MAXIMUM AND MINIMUM AGE \n");
			System.out.printf("Maximum Age:" +String.format("%3s", maxAge)  + "\n");
			System.out.printf("Minimum Age:" +String.format("%3s", minAge)  + "\n");
			System.out.printf("...............................................\n");
			
			try {
				fw.write("MAXIMUM AND MINIMUM AGE \n");
				fw.write("Maximum Age:" +String.format("%3s", maxAge)  + "\n");
				fw.write("Minimum Age:" +String.format("%3s", minAge)  + "\n");
				fw.write("...............................................\n");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
}
