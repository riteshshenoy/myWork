package BankRecords;
import java.util.Comparator;

public class RegionComparator implements Comparator<BankRecords> {

	@Override
	public int compare(BankRecords arg0, BankRecords arg1) {
		// TODO Auto-generated method stub
		int result = arg0.getRegion().compareTo(arg1.getRegion());
		return result;
	}
}
